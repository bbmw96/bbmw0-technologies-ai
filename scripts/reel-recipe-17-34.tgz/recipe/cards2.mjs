import fs from "fs";
import crypto from "crypto";
import { chromium } from "playwright-core";
const eds = "quran-uthmani,en.sahih,zh.jian,ko.korean,ja.japanese,ms.basmeih,th.thai,es.cortes";
const j = await (await fetch(`https://api.alquran.cloud/v1/ayah/17:34/editions/${eds}`)).json();
const by = {}; for (const d of j.data) by[d.edition.identifier] = d.text;
const sha = crypto.createHash("sha1").update(Object.keys(by).sort().map(k => k + "|" + by[k]).join("\n")).digest("hex");
console.log("sha1", sha); if (sha !== "73a4df70622aa41ad5bb656c26b927bb4893cbd7") throw new Error("differs from device fetch");
const tk = by["quran-uthmani"].split(" "); const w = tk.indexOf("ۚ"); if (w < 3) throw new Error("no waqf");
const clip = {
 "quran-uthmani": tk.slice(w + 1).join(" "),
 "en.sahih": "And fulfill [every] commitment. Indeed, the commitment is ever [that about which one will be] questioned.",
 "zh.jian": "你们应当履行诺言；诺言确是要被审问的事。",
 "ko.korean": "그리고 계약을 이행하라 그 모든 계약에 대하여 질문을 받으리라",
 "ja.japanese": "約束を果たしなさい。凡ての約束は，（審判の日）尋問されるのである。",
 "ms.basmeih": "dan sempurnakanlah perjanjian (dengan Allah dan dengan manusia), sesungguhnya perjanjian itu akan ditanya.",
 "th.thai": "และจงให้ครบตามสัญญา (เพราะ) แท้จริงสัญญานั้นจะถูกสอบสวน",
 "es.cortes": "¡Cumplid todo compromiso, porque se pedirá cuenta de él!" };
for (const [k, v] of Object.entries(clip)) if (!by[k].endsWith(v)) throw new Error("not a verbatim suffix: " + k);
console.log("AR:", clip["quran-uthmani"]);
fs.writeFileSync("clip-17-34.json", JSON.stringify(clip, null, 1));
const L = [["quran-uthmani","ar","AR","العربية","Uthmani script","amiri"],["en.sahih","en","EN","ENGLISH","Saheeh International","sans"],["zh.jian","zh","ZH","中文","Ma Jian","cjk"],["ko.korean","ko","KO","한국어","Translator not specified by source","cjk"],["ja.japanese","ja","JA","日本語","Translator not specified by source","cjk"],["ms.basmeih","ms","MS","MELAYU","Abdullah Muhammad Basmeih","sans"],["th.thai","th","TH","ภาษาไทย","King Fahad Quran Complex","thai"],["es.cortes","es","ES","ESPAÑOL","Julio Cortes","sans"]];
const font = p => "file://" + process.cwd() + "/node_modules/@fontsource/" + p;
const css = `@font-face{font-family:Amiri;src:url(${font("amiri/files/amiri-arabic-700-normal.woff2")});font-weight:700}
@font-face{font-family:ThaiF;src:url(${font("noto-sans-thai/files/noto-sans-thai-thai-600-normal.woff2")});font-weight:600}
html,body{margin:0;width:720px;height:1280px;background:transparent;overflow:hidden}
.scrim{position:absolute;left:0;right:0;bottom:0;height:760px;background:linear-gradient(to top,rgba(5,12,8,.88),rgba(5,12,8,.7) 55%,rgba(5,12,8,0))}
.top{position:absolute;left:48px;top:64px;color:#fff;text-shadow:0 2px 10px #000;font-family:'DejaVu Sans',sans-serif}
.top .a{font:700 21px 'DejaVu Sans';letter-spacing:.22em;color:#E9C46A}
.top .b{font:600 30px 'DejaVu Sans';margin-top:10px;letter-spacing:.06em}
.top .c{font:500 20px 'DejaVu Sans';margin-top:8px;opacity:.8}
.chips{position:absolute;left:48px;right:48px;bottom:112px;display:flex;gap:12px;font:700 19px 'DejaVu Sans';letter-spacing:.12em}
.chip{padding:6px 12px;border-radius:999px;border:1.5px solid rgba(255,255,255,.35);color:rgba(255,255,255,.6)}
.chip.on{background:#E9C46A;border-color:#E9C46A;color:#10170f}
.blk{position:absolute;left:48px;right:48px;bottom:190px;display:flex;gap:22px;color:#fff;text-shadow:0 2px 10px rgba(0,0,0,.85)}
.bar{width:6px;border-radius:3px;background:#E9C46A;flex:none}
.lab{font:700 21px 'Noto Sans CJK JP','DejaVu Sans';letter-spacing:.16em;color:#E9C46A;margin-bottom:14px}
.txt{font-weight:700;line-height:1.48}
.note{font:500 19px 'DejaVu Sans','Noto Sans CJK JP';opacity:.85;margin-top:16px}
.h{position:absolute;left:48px;bottom:52px;font:600 24px 'DejaVu Sans';color:#fff;text-shadow:0 2px 10px #000}`;
const fam = { amiri: "Amiri,serif", sans: "'DejaVu Sans','Noto Sans CJK JP',sans-serif", cjk: "'Noto Sans CJK JP','Noto Sans CJK HK',sans-serif", thai: "ThaiF,Loma,sans-serif" };
const b = await chromium.launch({ executablePath: "/opt/pw-browsers/chromium", args: ["--no-sandbox"] });
const pg = await b.newPage({ viewport: { width: 720, height: 1280 } });
const esc = s => s.replace(/&/g, "&amp;").replace(/</g, "&lt;");
const top = `<div class="top"><div class="a">PROMISES · PART 3</div><div class="b">AL-ISRA · 17:34</div><div class="c">Second half of the verse</div></div>`;
let i = 0;
for (let k = 0; k <= L.length; k++) {
  const chips = L.map(([, , s], n) => `<div class="chip ${n === k ? "on" : ""}">${s}</div>`).join("");
  let body;
  if (k === L.length) body = `<div class="blk"><div class="bar"></div><div><div class="lab">SOURCES</div><div class="note" style="font-size:23px;line-height:1.7;margin:0;opacity:1">Qur'an 17:34, Surah Al-Isra (second half)<br>Arabic: Uthmani script · English: Saheeh International<br>Chinese: Ma Jian · Malay: Abdullah Muhammad Basmeih<br>Thai: King Fahad Quran Complex · Spanish: Julio Cortes<br>Korean and Japanese: translator not specified by source<br>Source: alquran.cloud</div></div></div>`;
  else { const [id, l, , lab, note, f] = L[k]; const t = clip[id]; const size = l === "ar" ? 50 : t.length > 90 ? 34 : (f === "cjk" ? 38 : 42);
    body = `<div class="blk" ${l === "ar" ? 'style="direction:rtl"' : ""}><div class="bar"></div><div style="flex:1"><div class="lab">${lab}</div><div class="txt" ${l === "ar" ? 'dir="rtl"' : ""} style="font-family:${fam[f]};font-size:${size}px;line-height:${l === "ar" ? 2.0 : 1.48}">${esc(t)}</div><div class="note">${note}</div></div></div>`; }
  fs.writeFileSync(`card-${i}.html`,`<meta charset=utf-8><style>${css}</style><div class="scrim"></div>${top}${body}${k < L.length ? `<div class="chips">${chips}</div>` : ""}<div class="h">@blankdiscussions</div>`); await pg.goto("file://"+process.cwd()+`/card-${i}.html`);
  await pg.evaluate(() => document.fonts.ready); await pg.waitForTimeout(250);
  await pg.screenshot({ path: `c2-${String(i).padStart(2, "0")}.png`, omitBackground: true }); i++;
}
await b.close(); console.log("cards", i);
